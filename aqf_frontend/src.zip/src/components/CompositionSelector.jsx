export default function CompositionSelector({
  groups,
  selectedGroups,
  selectedSections,
  onToggleGroup,
  onToggleSection
}) {
  return (
    <aside className="panel">
      <div className="panel-header">
        <div>
          <div className="eyebrow">1. Clinical records</div>
          <h2>Repository Explorer</h2>
        </div>
      </div>

      <div className="stack">
        {groups.map((group) => {
          const isSelected = selectedGroups.includes(group.label)
          const sectionCount = group.sections?.length || 0
          return (
            <div key={group.group_id} className={`card ${isSelected ? 'card-selected' : ''}`}>
              <label className="row">
                <input
                  type="checkbox"
                  checked={isSelected}
                  onChange={() => onToggleGroup(group.label)}
                />
                <div>
                  <div className="card-title">{group.displayLabel || group.label}</div>
                  <div className="muted">{group.fields?.length || 0} fields · {sectionCount} sections</div>
                </div>
              </label>

              {isSelected ? (
                <div className="nested">
                  {(group.sections || []).map((section) => {
                    const checked = selectedSections.includes(section.key)
                    return (
                      <label key={section.key} className={`section-chip ${checked ? 'section-chip-on' : ''}`}>
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() => onToggleSection(section.key)}
                        />
                        <span>{section.displayLabel || section.label}</span>
                        {/* <span className="tiny">{section.fields?.length || 0}</span> */}
                      </label>
                    )
                  })}
                </div>
              ) : null}
            </div>
          )
        })}
      </div>
    </aside>
  )
}
