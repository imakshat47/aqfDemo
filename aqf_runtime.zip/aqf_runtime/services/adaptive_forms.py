class AdaptiveFormGenerator:
    pass
