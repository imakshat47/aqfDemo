class CandidateSelector:
    pass
