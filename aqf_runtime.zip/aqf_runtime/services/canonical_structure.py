class CanonicalStructureBuilder:
    pass
