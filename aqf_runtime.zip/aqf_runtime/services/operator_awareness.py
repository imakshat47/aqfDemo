class OperatorAwareness:
    pass
