class QueryRealizer:
    pass
